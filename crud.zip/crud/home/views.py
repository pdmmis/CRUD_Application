from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'app/home.html')
def login(request):
    return render(request,'app/login.html')
def table(request):
    return render(request,'app/table.html')
def update(request):
    return render(request,'app/update.html')
def welcome(request):
    return render(request,'app/welcome.html')
    
